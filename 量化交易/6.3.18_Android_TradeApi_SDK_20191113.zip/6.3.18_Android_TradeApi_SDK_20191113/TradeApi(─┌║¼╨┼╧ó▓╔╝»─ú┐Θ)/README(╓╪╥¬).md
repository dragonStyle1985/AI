# 1. 文件目录结构说明
	主目录
	|
	|-TradeApi_release_v1.5-xxx.aar:TradeApi模块aar文件。

TradeApi_release_v1.5-xxx.aar集成了TradeApi和信息采集模块所需内容，无需再额外添加信息采集模块。
PS:xxx代表日期。

模块中提供的登录接口(CThostFtdcTraderApi->ReqUserLogin)，内部自动获取采集信息并完成上报，无需使用者手动调用获取采集信息接口。

# 2. 开发环境要求

开发者在使用SDK的时候需要配置Kotlin开发环境，否则无法正常使用。

# 3. 应用权限配置

模块内部在获取采集信息时，首先会判断应用是否具备对应的权限，若无权限则涉及到采集项会无法获取。
因此在使用信息采集模块前，应用需要请申请模块所需要的权限。

使用到的权限如下(可能会根据需求变动)：
```
​    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE"/>
​    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
​    <uses-permission android:name="android.permission.READ_PHONE_STATE"/>
​    <uses-permission android:name="android.permission.INTERNET"/>
​    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
​    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
```

> 在Android 10中，针对获取位置信息新增了一个权限[ACCESS_BACKGROUND_LOCATION],SDK在获取位置信息的时候，并不会判断应用是否具备该权限，请应用根据实际情况申请/添加该权限。

# 4. CPU架构/Android系统支持

## 4.1 CPU架构
目前SDK支持armeabi/armeabi-v7a/arm64-v8a/x86/x86_64，不支持mips/mips64架构。

## 4.2 Android系统支持

当前SDK已完成Android 10的适配，支持Android 5.0-Android 10。

编译SDK使用到的一些配置信息：
```
    compileSdkVersion 29
    buildToolsVersion '29.0.2'
    
    minSdkVersion 21
    targetSdkVersion 29
```


# 5. 如何配置并使用aar

1. 将aar文件放入moudle中的libs文件夹下。
2. 修改module的build.gradle文件，添加如下配置：
android {  
	repositories{
        flatDir{
            dirs "libs"
        }
    }
}

dependencies {
	api(name: "TradeApi_release_v1.5-xxx", ext: "aar")
}


# 6. 代码示例

示例使用Kotlin语言描述。

PS:
1. 调用CreateFtdcTraderApi方法时，必须传入应用可读写的路径；根据路径的不同，可能需要应用具有读写外部存储的权限。
2. 调用RegisterSpi注册回调CThostFtdcTraderSpi时，参数CThostFtdcTraderSpi的实例不能声明为局部变量。
3. 请按照要求配置/申请权限。
4. 不建议调用Release接口。
5. 对于CThostFtdcTraderSpi的继承实现，建议使用java实现。
   如果使用Kotlin实现的话，一定要注意字段的可空性，否则极有可能会出现回调异常，而原因仅仅是因为返回的字段为空，而对应的Kotlin回调接口声明里写的却是非空。

CThostFtdcTraderSpi示例：

```java
	// 1. java方式
	// pTradingAccount可能为空，如果使用java方式，则只需要在方法内部判断即可。
	@Override
	public void OnRspQryTradingAccount(CThostFtdcTradingAccountField pTradingAccount, CThostFtdcRspInfoField pRspInfo, int nRequestID, boolean bIsLast) {
		Log.e(TAG, "OnRspQryTradingAccount");
		if (bIsLast == true) {
			if (pTradingAccount != null) {
				Log.e(TAG, pTradingAccount.getAccountID() + "，可用资金为:" + pTradingAccount.getAvailable();
			} else {
				Log.e(TAG,"查询到的账户信息为空");
			}
		}
	}

	// 2.Kotlin方式
	// pTradingAccount与pRspInfo等一定要声明为是可空类型的(?)，否则当返回值为空的时候，一定会出现运行时异常。
	// 这是由Kotlin的设计机制导致的，可空类型与非可空类型之间的区别。
	override fun OnRspQryTradingAccount(pTradingAccount: CThostFtdcTradingAccountField?, pRspInfo: CThostFtdcRspInfoField?, nRequestId: Int, bIsLast: Boolean) {
		Log.e(TAG, "OnRspQryTradingAccount");
		if (bIsLast == true) {
			if (pTradingAccount != null) {
				Log.e(TAG, pTradingAccount.getAccountID() + "结算准备金:" + pTradingAccount.getBalance() + "，可用资金为:" + pTradingAccount.getAvailable());
			} else {
				Log.e(TAG,"查询到的账户信息为空");
			}
		}
	}

```


## 6.1 加载动态库

```
	companion object {
		init {
			try {
				System.loadLibrary("thosttraderapi")
				System.loadLibrary("thosttraderapi_wrap")
			} catch (e: Exception) {
				e.printStackTrace()
			}
		}
	}
```

## 6.2 初始化API

```
	fun initTradeApi() {
		// apppath应该是应用可读写的路径，一般使用应用内路径
		apppath = this.applicationContext.filesDir.absolutePath + "/"
		// CreateFtdcTraderApi方法的参数不能为空
		Global.sTradeApi = CThostFtdcTraderApi.CreateFtdcTraderApi(apppath)
		// CTPTradeHandler继承CThostFtdcTraderSpi，负责事件回调处理
		// traderHandler不要声明为局部变量，否则会出错。
		traderHandler = CTPTradeHandler()
		Global.sTradeApi.RegisterSpi(traderHandler)
		Global.sTradeApi.RegisterFront(ConfigReader.m_strFrontAddr)
		Global.sTradeApi.SubscribePublicTopic(THOST_TE_RESUME_TYPE.swigToEnum(ConfigReader.m_iResumeType))
		Global.sTradeApi.SubscribePrivateTopic(THOST_TE_RESUME_TYPE.swigToEnum(ConfigReader.m_iResumeType))
		Global.sTradeApi.Init()
	}
```


## 6.3 认证

```
	fun ReqAuthenticate() {
		val field = CThostFtdcReqAuthenticateField()
		field.brokerID = ConfigReader.m_strBrokerID
		field.userID = ConfigReader.m_strInvestorID
		field.userProductInfo = ConfigReader.m_strProductInfo
		// AuthCode与AppID需要申请
		field.authCode = ConfigReader.m_strAuthenCode
		field.appID = ConfigReader.m_strAppId
		val code = Global.sTradeApi?.ReqAuthenticate(field, 10000)
		Log.e("===", "ReqAuthenticate:$code")
	}

```

对应的CTPTradeHandler事件回调为：CTPTradeHandler->OnRspAuthenticate.


## 6.4 登录

```
	fun ReqUserLogin(context:Context) {
		// 调用接口获取采集信息
		val loginFiled = CThostFtdcReqUserLoginField()
		loginFiled.brokerID = ConfigReader.m_strBrokerID
		loginFiled.userID = ConfigReader.m_strInvestorID
		loginFiled.password = ConfigReader.m_strPassword
		loginFiled.userProductInfo = ConfigReader.m_strProductInfo
		// 调用登录接口进行登录，注意需要使用参数context
		val code = Global.sTradeApi.ReqUserLogin(context,loginFiled,10001)
		Log.e("===", "ReqUserLogin:$code")
	}

```
对应的CTPTradeHandler事件回调为：CTPTradeHandler->OnRspUserLogin.

PS:直连模式下，登录接口内部自动完成信息采集和上报。