# 1. 说明

文件名称：InfoCollection_single_release_v1.5-xxx.aar

xxx代表日期。

该文件仅适用于单独采集信息的情景。

# 2. 开发环境要求

开发者在使用SDK的时候需要配置Kotlin开发环境，否则采集模块无法正常使用。

# 3. 应用权限配置

信息采集模块采集信息时，需要应用具备某些权限。
采集模块在采集信息的时候对使用权限进行判断，若应用不具备某些权限，可能会导致获取到对应的采集项为空。
因此在使用信息采集模块前，应用需要请申请采集模块所需要的权限。

使用到的权限如下(可能会根据需求变动)：
```
​    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE"/>
​    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
​    <uses-permission android:name="android.permission.READ_PHONE_STATE"/>
​    <uses-permission android:name="android.permission.INTERNET"/>
​    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
​    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
```

> 在Android 10中，针对获取位置信息新增了一个权限[ACCESS_BACKGROUND_LOCATION],SDK在获取位置信息的时候，并不会判断应用是否具备该权限，请根据应用的实际情况申请/添加该权限。


# 4. 支持

## 4.1 CPU架构
目前SDK支持armeabi/armeabi-v7a/arm64-v8a/x86/x86_64，不支持mips/mips64架构。

## 4.2 Android系统支持

当前SDK已完成Android 10的适配，支持Android 5.0-Android 10。

编译SDK使用到的一些配置信息：
```
    compileSdkVersion 29
    buildToolsVersion '29.0.2'
    
    minSdkVersion 21
    targetSdkVersion 29
```



# 5. 如何配置并使用aar

1. 将aar文件放入moudle中的libs文件夹下。
2. 修改module的build.gradle文件，添加如下配置：
android {  
	repositories{
        flatDir{
            dirs "libs"
        }
    }
}

dependencies {
	api(name: "InfoCollection_single_release_v1.5-xxx", ext: "aar")
}

# 6. 代码示例

PS:直接调用接口，无需手动加载动态库。

```java
byte[] collectInfo = DeviceInfoManager.getCollectInfo(context);
```


