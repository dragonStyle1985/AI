# 1. 文件目录结构说明
	主目录
	|
	|--TradeApi(内含信息采集模块):存放TradeApi模块文件。
	|
	|
	|--信息采集模块(单独使用):存放单独使用的信息采集模块文件

# 2. 说明

此版本使用[生产版密钥]，为监控中心生产密钥。

[建议及时更新SDK，以避免旧版本中出现的问题。]

# 3. 本次更新内容

1. 适配最新的Android 10系统，compileSdkVersion 29。
2. 支持的Android系统版本：Android 5.0 - Android 10。
3. 针对Android 10修改部分使用说明。
4. 受Android 10系统影响，根据分析和测试，受影响的采集项包括：IMEI/MEID/设备序列号/IMSI/ICCID/Mac Address。